# Security notes — RHM 2027 VIP

## Important limitation: static admin gate

`Studio.html` is delivered as public client-side code. A PIN check implemented in HTML/JavaScript and `sessionStorage` is only a convenience gate; it is **not authentication** and cannot protect the editor or its data from someone who can inspect or modify the browser. Do not store confidential questions, private student data, API keys, or other secrets in this repository or in browser code.

For real access control, move Studio behind a server-side authentication layer (or a trusted identity provider with server-enforced authorization). A GitHub Pages-only deployment cannot provide secret client-side authentication.

## Data rendering

Question and reading content supports the documented `[B]`, `[RED]`, `[BLUE]`, `[BR]`, and `[IMG]` shortcodes. The reader/quiz/flashcard renderers now escape source text before interpreting those shortcodes and allow only HTTP(S) image URLs. Continue treating all Google Sheets content as untrusted input.

## Deployment

- Serve the app over HTTPS.
- Do not commit API keys or credentials.
- Restrict who can edit the published Google Sheets sources.
- Review third-party CDN dependencies before adding them to the app shell.
