/* RHM 2027 VIP — resilient offline cache */
const CACHE_NAME = 'rhm-2027-vip-v2';
const APP_SHELL = [
  './', './index.html', './Play.html', './Flashcard.html', './Read.html',
  './Studio.html', './manifest.json', './icon.svg'
];
const OPTIONAL_ASSETS = [
  'https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    // App shell is required; optional CDN assets must never block installation.
    await cache.addAll(APP_SHELL);
    await Promise.allSettled(OPTIONAL_ASSETS.map(async (url) => {
      try {
        const response = await fetch(url, { mode: 'no-cors' });
        if (response && (response.type === 'opaque' || response.ok)) await cache.put(url, response);
      } catch (_) { /* optional dependency remains available when online */ }
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((key) => key.startsWith('rhm-2027-vip-') && key !== CACHE_NAME)
      .map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);

  // Google Sheets: always prefer fresh data, fall back to last successful response.
  if (url.hostname === 'docs.google.com' && url.pathname.includes('/spreadsheets/')) {
    event.respondWith((async () => {
      try {
        const response = await fetch(request);
        if (response.ok) {
          const cache = await caches.open(CACHE_NAME);
          await cache.put(request, response.clone());
        }
        return response;
      } catch (_) {
        return (await caches.match(request)) || new Response('Không có dữ liệu ngoại tuyến.', {
          status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' }
        });
      }
    })());
    return;
  }

  // Ignore unrelated third-party requests; cache only app assets and known optional CDN.
  const isAppAsset = url.origin === self.location.origin;
  const isOptionalAsset = OPTIONAL_ASSETS.includes(request.url);
  if (!isAppAsset && !isOptionalAsset) return;

  event.respondWith((async () => {
    const cached = await caches.match(request);
    // HTML navigations prefer the network for updates, with an offline app-shell fallback.
    if (request.mode === 'navigate') {
      try {
        const response = await fetch(request);
        if (response && response.ok) {
          const cache = await caches.open(CACHE_NAME);
          await cache.put(request, response.clone());
        }
        return response;
      } catch (_) { return cached || (await caches.match('./index.html')); }
    }
    // Other app assets use stale-while-revalidate.
    const network = fetch(request).then(async (response) => {
      if (response && (response.ok || response.type === 'opaque')) {
        const cache = await caches.open(CACHE_NAME);
        await cache.put(request, response.clone());
      }
      return response;
    }).catch(() => cached);
    return cached || await network || new Response('', { status: 504 });
  })());
});
